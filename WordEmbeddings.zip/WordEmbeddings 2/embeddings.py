import numpy as np
import pickle
import os


class WordEmbeddings:
    def __init__(self):
        self.embeddings = {}

    def load_glove(self, file_path, pkl_path="glove_embeddings.pkl"):
        if os.path.exists(pkl_path):
            print("Loading cached embeddings...")
            with open(pkl_path, "rb") as f:
                self.embeddings = pickle.load(f)
        else:
            print("Loading GloVe from text...")
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split()
                    word = parts[0]
                    vector = np.array(parts[1:], dtype=np.float32)

                    norm = np.linalg.norm(vector)
                    if norm != 0:
                        vector = vector/norm
                    self.embeddings[word] = vector
            with open(pkl_path, "wb") as f:
                pickle.dump(self.embeddings, f)
            print(f"Cached {len(self.embeddings)} embeddings to {pkl_path}")

    def get_vector(self, word):
        return self.embeddings.get(word, None)
