from embeddings import WordEmbeddings
from utils import cosine_similarity, most_similar, analogy

glove_path = "/Users/saadismail/Downloads/glove/glove.6B.300d.txt"
cached_path = "glove.6B.300d.pkl"
model = WordEmbeddings()
model.load_glove(glove_path, pkl_path=cached_path)


print("\nCosine Similarity:")
print(f"king vs queen: {cosine_similarity(model.get_vector('king'), model.get_vector('queen'))}")
print(f"king vs banana: {cosine_similarity(model.get_vector('king'), model.get_vector('banana'))}")

print("\nMost similar words to Oka 'paris':")
for word, score in most_similar("paris", model):
    print(f"{word}: {score:.4f}")

print("\nAnalogy: parrot - bird + fish = ?")
for word, score in analogy("woman", "girl", "boy", model):
    print(f"{word}: {score:.4f}")
