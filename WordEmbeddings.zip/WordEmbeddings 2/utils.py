import numpy as np
from embeddings import WordEmbeddings


def cosine_similarity(vec1, vec2):
    """Compute cosine similarity between two vectors"""
    if vec1 is None or vec2 is None:
        return -1

    dot = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    return dot / (norm1 * norm2)


def most_similar(word, embeddings, top_n=5):
    """Find top-n most similar words to given word"""
    target_vec = embeddings.get_vector(word)
    if target_vec is None:
        return []

    scores = []
    for w, vec in embeddings.embeddings.items():
        if w == word:
            continue
        sim = cosine_similarity(target_vec, vec)
        scores.append((w, sim))

    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:top_n]


def analogy(word_a, word_b, word_c, embeddings, top_n=1):
    """Solve analogy: A - B + C = ?"""
    vec_a = embeddings.get_vector(word_a)
    vec_b = embeddings.get_vector(word_b)
    vec_c = embeddings.get_vector(word_c)

    if any(v is None for v in [vec_a, vec_b, vec_c]):
        return []

    target_vec = vec_c - vec_b + vec_a
    target_vec = target_vec / np.linalg.norm(target_vec)
    scores = []
    for w, vec in embeddings.embeddings.items():
        if w in [word_a, word_b, word_c]:
            continue
        sim = cosine_similarity(target_vec, vec)
        scores.append((w, sim))

    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:top_n]
